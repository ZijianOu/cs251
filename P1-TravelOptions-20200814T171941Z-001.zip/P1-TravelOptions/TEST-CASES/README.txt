

  .zip file has exact same contents as the uncompressed folder 'test-suite'

  download them however you please... and then read file 'Readme_tests.txt'
